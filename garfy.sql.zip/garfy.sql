-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2016 at 04:46 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `garfy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_t`
--

CREATE TABLE IF NOT EXISTS `admin_t` (
  `admin_id` int(8) NOT NULL,
  `pin` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `arf_t`
--

CREATE TABLE IF NOT EXISTS `arf_t` (
  `arf_id` int(11) NOT NULL,
  `user_id` int(8) NOT NULL,
  `title` varchar(32) NOT NULL,
  `content` text NOT NULL,
  `arf_date` date NOT NULL,
  `arf_expiry_date` date NOT NULL,
  `post_to` varchar(255) NOT NULL,
  `viewable_to` text NOT NULL,
  `confirm_by` enum('student affairs officer','pastoral animator','chairpersons','dean','rector') NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` enum('active','expired') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arf_t`
--

INSERT INTO `arf_t` (`arf_id`, `user_id`, `title`, `content`, `arf_date`, `arf_expiry_date`, `post_to`, `viewable_to`, `confirm_by`, `remarks`, `status`) VALUES
(1, 0, 'title', 'testing', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(2, 0, 'title', 'testing', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(3, 0, 'title', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(4, 0, 'title', '', '2016-02-17', '0000-00-00', '', '', 'pastoral animator', NULL, 'active'),
(5, 0, 'title', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(6, 0, 'title', 'hfyfyfyfycf', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(7, 0, 'title', 'hfyfyfyfycf', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(8, 0, 'title', 'hfyfyfyfycf', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(9, 0, 'title', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(10, 0, 'title', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(11, 0, '', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(12, 0, '', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(13, 0, 'tittjtht', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(14, 0, 'ryrdhf', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(15, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(16, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(17, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(18, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(19, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(20, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(21, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(22, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(23, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(24, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(25, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(26, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(27, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(28, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(29, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(30, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(31, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(32, 0, '', '', '2016-02-17', '0000-00-00', '', '', '', NULL, 'active'),
(33, 0, 'dufhhfdisosso', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(34, 0, 'usidititdttd', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(35, 0, 'usidititdttd', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(36, 0, 'usidititdttd', '', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(37, 0, 'edgar', 'williams ', '2016-02-17', '0000-00-00', '', '', 'student affairs officer', NULL, 'active'),
(38, 0, 'edgar', 'williams ', '2016-02-17', '0000-00-00', 'Array', '', 'student affairs officer', NULL, 'active'),
(39, 0, 'qqwrty', 'yfyfguuvuvhv', '2016-02-17', '0000-00-00', 'Array', '', 'chairpersons', NULL, 'active'),
(40, 0, 'qqwrty', 'yfyfguuvuvhv', '2016-02-17', '0000-00-00', 'student affairs, student affairs', 'all', 'chairpersons', NULL, 'active'),
(41, 0, 'ydiyddt', '', '2016-02-17', '0000-00-00', 'student affairs, faculty, dean, guidance, pastoral animation, library, training and research, i.t. student org, i.e. student org, t.e. student org, m.e. student org, e.c.e. student org', 'all', 'dean', NULL, 'active'),
(42, 0, 'ytrewq', 'qwrty', '2016-02-17', '0000-00-00', 'student affairs, faculty, dean, guidance, pastoral animation, library, training and research, i.t. student org, i.e. student org, t.e. student org, m.e. student org, e.c.e. student org', 'all, employees only, faculty, personnel under vp of ed, personnel under rector', 'rector', NULL, 'active'),
(43, 0, 'ytrewq', 'qwrty', '2016-02-17', '0000-00-00', 'student affairs, faculty, dean, guidance, pastoral animation, library, training and research, i.t. student org, i.e. student org, t.e. student org, m.e. student org, e.c.e. student org, student affairs, faculty, dean, guidance, pastoral animation, library', 'all, employees only, faculty, personnel under vp of ed, personnel under rector, all, employees only, faculty, personnel under vp of ed, personnel under rector', 'rector', NULL, 'active'),
(44, 0, 'cmon', 'come on', '2016-02-17', '0000-00-00', 'faculty, pastoral animation', 'all, employees only', 'student affairs officer', NULL, 'active'),
(45, 0, '7dt57e57', 'jtsjsjtsjtdi', '2016-02-17', '0000-00-00', 'student affairs, dean, pastoral animation, t.e. student org, e.c.e. student org', 'personnel under vp of ed', 'chairpersons', NULL, 'active'),
(46, 0, 'ruujfnfjffrriir', 'rruur6r6r6rr', '2016-02-17', '0000-00-00', 'student affairs, dean', 'employees only', 'student affairs officer', NULL, 'active'),
(47, 0, 'wfefefegege', 'rhfjdididid', '2016-02-17', '0000-00-00', 'faculty, dean', 'employees only, faculty', 'pastoral animator', NULL, 'active'),
(48, 0, 'wfefefegege', 'rhfjdididid', '2016-02-17', '0000-00-00', 'faculty, dean, faculty, dean', 'employees only, faculty, employees only, faculty', 'pastoral animator', NULL, 'active'),
(49, 0, 'test', 'testing', '2016-02-18', '0000-00-00', 'student affairs, library', 'employees only, personnel under vp of ed', 'pastoral animator', NULL, 'active'),
(50, 0, 'ugugugu', 'ugufu', '2016-02-18', '0000-00-00', 'faculty, guidance', 'employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(51, 11049169, 'ugugugu', 'ugufu', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(52, 11049169, 'test userid', 'uffusfixgc', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(53, 11049169, 'test userid', 'manage arf log', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(54, 11049169, 'test userid', 'manage arf log', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(55, 11049169, 'test userid', 'manage arf log', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(56, 11049169, 'test userid', 'manage arf log', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(57, 11049169, 'test userid', 'manage arf log', '2016-02-18', '2016-02-23', 'faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance, faculty, guidance', 'employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed, employees only, personnel under vp of ed', 'chairpersons', NULL, 'active'),
(58, 11049169, 'test', '', '2016-02-18', '2016-02-29', 'student affairs, dean, guidance', 'all, faculty', 'student affairs officer', NULL, 'active'),
(59, 1, 'yay', 'yahooooo', '2016-02-18', '2016-02-18', 'student affairs, dean, guidance', 'all, personnel under rector', 'student affairs officer', NULL, 'active'),
(60, 11049169, 'cigdkgd', 'hykkykdfkgd', '2016-02-18', '2016-02-18', 'student affairs', 'all', 'student affairs officer', NULL, 'active'),
(61, 3, 'toshi', 'ba', '2016-02-22', '2016-02-29', 'student affairs, faculty, dean, pastoral animation', 'employees only, faculty', 'student affairs officer', NULL, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `employee_t`
--

CREATE TABLE IF NOT EXISTS `employee_t` (
  `employee_id` int(11) NOT NULL,
  `position` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manage_arf_log_t`
--

CREATE TABLE IF NOT EXISTS `manage_arf_log_t` (
  `user_id` int(8) NOT NULL,
  `arf_id` int(11) NOT NULL,
  `manage_arf_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` enum('draft','censor approved','censor rejected','approved','rejected','pending','created') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manage_arf_log_t`
--

INSERT INTO `manage_arf_log_t` (`user_id`, `arf_id`, `manage_arf_timestamp`, `type`) VALUES
(1, 59, '2016-02-18 01:32:27', 'created'),
(3, 61, '2016-02-22 06:21:41', 'created'),
(11049169, 57, '2016-02-18 01:02:35', 'created'),
(11049169, 58, '2016-02-18 01:12:54', 'created'),
(11049169, 60, '2016-02-18 03:59:49', 'created');

-- --------------------------------------------------------

--
-- Table structure for table `manage_notification_log_t`
--

CREATE TABLE IF NOT EXISTS `manage_notification_log_t` (
  `tech_id` int(8) NOT NULL,
  `notification_id` int(11) NOT NULL,
  `manage_reset_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` enum('password','activate','deactivate') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manage_reset_log_t`
--

CREATE TABLE IF NOT EXISTS `manage_reset_log_t` (
  `admin_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `manage_reset_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` enum('password','activate','deactivate') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manage_user_log_t`
--

CREATE TABLE IF NOT EXISTS `manage_user_log_t` (
  `user_id` int(8) NOT NULL,
  `toUser_id` int(8) NOT NULL,
  `manage_user_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` enum('create','edit','password change','pin change') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notification_t`
--

CREATE TABLE IF NOT EXISTS `notification_t` (
  `notification_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `arf_date` date NOT NULL,
  `status` enum('active','expired') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_t`
--

CREATE TABLE IF NOT EXISTS `student_t` (
  `student_id` int(8) NOT NULL,
  `course` enum('BSECE','BSIE','BSIT','BSME','BSTE') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_t`
--

CREATE TABLE IF NOT EXISTS `user_t` (
  `user_id` int(8) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `e_first_name` varchar(32) NOT NULL,
  `e_last_name` varchar(32) NOT NULL,
  `contact_number` varchar(16) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `level` enum('low','mid','high','tech') DEFAULT NULL,
  `active` enum('yes','no') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_t`
--

INSERT INTO `user_t` (`user_id`, `first_name`, `last_name`, `e_first_name`, `e_last_name`, `contact_number`, `password`, `level`, `active`) VALUES
(1, 'John', 'Huffman', 'Linda', 'huffman', '8507853244', '5f4dcc3b5aa765d61d8327deb882cf99', 'high', 'yes'),
(2, 'Richard', 'Theobald', 'Michael', 'Theobald', '8505205323', '5f4dcc3b5aa765d61d8327deb882cf99', 'mid', 'yes'),
(3, 'angelina', 'mullholland', 'derek', 'mullholland', '8507851111', '098f6bcd4621d373cade4e832627b4f6', 'low', 'yes'),
(4, 'deke', 'mccoy', 'amber', 'mccoy', '8502225555', '5f4dcc3b5aa765d61d8327deb882cf99', 'tech', 'yes'),
(11049169, 'edgar', 'williams', 'yvonne', 'williams', '09392464094', '5f4dcc3b5aa765d61d8327deb882cf99', 'low', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `view_arf_log_t`
--

CREATE TABLE IF NOT EXISTS `view_arf_log_t` (
  `user_id` int(8) NOT NULL,
  `arf_id` int(11) NOT NULL,
  `view_arf_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_t`
--
ALTER TABLE `admin_t`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `arf_t`
--
ALTER TABLE `arf_t`
  ADD PRIMARY KEY (`arf_id`);

--
-- Indexes for table `employee_t`
--
ALTER TABLE `employee_t`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `manage_arf_log_t`
--
ALTER TABLE `manage_arf_log_t`
  ADD PRIMARY KEY (`user_id`,`arf_id`), ADD KEY `arf_id` (`arf_id`);

--
-- Indexes for table `manage_notification_log_t`
--
ALTER TABLE `manage_notification_log_t`
  ADD PRIMARY KEY (`tech_id`,`notification_id`), ADD KEY `notification_id` (`notification_id`);

--
-- Indexes for table `manage_reset_log_t`
--
ALTER TABLE `manage_reset_log_t`
  ADD PRIMARY KEY (`admin_id`,`user_id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `manage_user_log_t`
--
ALTER TABLE `manage_user_log_t`
  ADD PRIMARY KEY (`user_id`,`toUser_id`), ADD KEY `toUser_id` (`toUser_id`);

--
-- Indexes for table `notification_t`
--
ALTER TABLE `notification_t`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `student_t`
--
ALTER TABLE `student_t`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `user_t`
--
ALTER TABLE `user_t`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `view_arf_log_t`
--
ALTER TABLE `view_arf_log_t`
  ADD PRIMARY KEY (`user_id`,`arf_id`), ADD KEY `arf_id` (`arf_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arf_t`
--
ALTER TABLE `arf_t`
  MODIFY `arf_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `notification_t`
--
ALTER TABLE `notification_t`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_t`
--
ALTER TABLE `admin_t`
ADD CONSTRAINT `admin_t_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `user_t` (`user_id`);

--
-- Constraints for table `employee_t`
--
ALTER TABLE `employee_t`
ADD CONSTRAINT `employee_t_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `user_t` (`user_id`);

--
-- Constraints for table `manage_arf_log_t`
--
ALTER TABLE `manage_arf_log_t`
ADD CONSTRAINT `manage_arf_log_t_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_t` (`user_id`),
ADD CONSTRAINT `manage_arf_log_t_ibfk_2` FOREIGN KEY (`arf_id`) REFERENCES `arf_t` (`arf_id`);

--
-- Constraints for table `manage_notification_log_t`
--
ALTER TABLE `manage_notification_log_t`
ADD CONSTRAINT `manage_notification_log_t_ibfk_1` FOREIGN KEY (`tech_id`) REFERENCES `admin_t` (`admin_id`),
ADD CONSTRAINT `manage_notification_log_t_ibfk_2` FOREIGN KEY (`notification_id`) REFERENCES `notification_t` (`notification_id`);

--
-- Constraints for table `manage_reset_log_t`
--
ALTER TABLE `manage_reset_log_t`
ADD CONSTRAINT `manage_reset_log_t_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin_t` (`admin_id`),
ADD CONSTRAINT `manage_reset_log_t_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_t` (`user_id`);

--
-- Constraints for table `manage_user_log_t`
--
ALTER TABLE `manage_user_log_t`
ADD CONSTRAINT `manage_user_log_t_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_t` (`user_id`),
ADD CONSTRAINT `manage_user_log_t_ibfk_2` FOREIGN KEY (`toUser_id`) REFERENCES `user_t` (`user_id`);

--
-- Constraints for table `student_t`
--
ALTER TABLE `student_t`
ADD CONSTRAINT `student_t_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `user_t` (`user_id`);

--
-- Constraints for table `view_arf_log_t`
--
ALTER TABLE `view_arf_log_t`
ADD CONSTRAINT `view_arf_log_t_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_t` (`user_id`),
ADD CONSTRAINT `view_arf_log_t_ibfk_2` FOREIGN KEY (`arf_id`) REFERENCES `arf_t` (`arf_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
